### Snippet Code Github with clipboard

Demo  : [mywebsite](https://abdfaisol.github.io/Snippet-Code-Github/)

You can use this feature just like this 

```html
<pre class="soft-git clipboard">
<code data-language="html">
<!--Your Code--->
</code>
</pre>
```

You can read available data-language on [rainbow](https://craig.is/making/rainbows)

Oh, Oh yes. I almost forgot. If you want to enter html code. You have to convert the character first. However, now you don't need to worry. You can use these services for free by using this website [texfixer](https://www.textfixer.com/html/html-character-encoding.php)

Thanks and see you

